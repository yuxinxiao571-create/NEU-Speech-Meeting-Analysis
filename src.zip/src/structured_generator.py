# src/structured_generator.py
import re
import torch
import pandas as pd
from openai import OpenAI
from sklearn.metrics.pairwise import cosine_similarity
from transformers import BertTokenizer, BertModel
from config import BERT_MODEL, SEMANTIC_SIMILARITY_THRESHOLD

class StructuredGenerator:
    def __init__(self, llm_api_key, llm_model):
        """
        初始化结构化报告生成模块
        :param llm_api_key: LLM API密钥
        :param llm_model: LLM模型名称
        """
        try:
            # 1. 初始化OpenAI客户端（支持GPT-3.5/4o）
            self.client = OpenAI(api_key=llm_api_key)
            self.llm_model = llm_model

            # 2. 加载BERT模型与Tokenizer（用于语义相似度校验）
            print(f"正在加载BERT模型：{BERT_MODEL}...")
            self.bert_tokenizer = BertTokenizer.from_pretrained(BERT_MODEL)
            self.bert_model = BertModel.from_pretrained(BERT_MODEL)
            # 设备配置（自动使用GPU，无GPU则用CPU）
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
            self.bert_model.to(self.device)
            self.bert_model.eval()  # 评估模式，关闭Dropout
            print(f"BERT模型加载完成，使用设备：{self.device}")

        except Exception as e:
            raise Exception(f"结构化生成模块初始化失败：{str(e)}")

    def format_input(self, aligned_df):
        """
        格式化输入数据：为LLM提供清晰的输入格式
        :param aligned_df: 对齐结果DataFrame
        :return: 格式化后的文本字符串
        """
        if aligned_df.empty:
            return ""

        formatted_text = "以下是会议对话的结构化原始数据（编号+时间戳+说话人+文本）：\n"
        for idx, row in aligned_df.iterrows():
            formatted_text += f"[{idx+1}] [{row['start']:.1f}s - {row['end']:.1f}s] {row['speaker']}: {row['text']}\n"

        return formatted_text

    def generate_structured(self, formatted_text):
        """
        调用LLM生成结构化会议报告
        :param formatted_text: 格式化后的原始输入
        :return: LLM生成的结构化报告
        """
        if len(formatted_text.strip()) == 0:
            return "无有效输入数据，无法生成结构化报告。"

        try:
            # 构造提示词（约束性提示，保证输出质量）
            prompt = f"""
            你的任务是基于提供的会议原始数据，生成一份层次清晰、内容准确的结构化会议报告。
            请严格遵循以下要求：
            1.  报告结构必须包含三个核心部分：「一、会议议题」「二、核心观点与专家意见」「三、讨论结果与待办事项」
            2.  仅基于输入数据生成内容，不得引入任何外部知识或主观推测
            3.  每条关键结论必须绑定至少一个原始数据编号（如[3]），方便追溯来源
            4.  优先保留会议中的冲突性、分歧性观点，不得遗漏重要差异
            5.  格式清晰，使用分点列出，语言简洁正式，符合学术/办公会议报告规范
            6.  去除冗余信息，提炼核心内容，避免逐句复述原始对话

            会议原始数据：
            {formatted_text}
            """

            # 调用LLM API
            response = self.client.chat.completions.create(
                model=self.llm_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,  # 降低随机性，保证输出稳定性
                max_tokens=2048  # 限制输出长度，避免超限
            )

            return response.choices[0].message.content.strip()

        except Exception as e:
            raise Exception(f"结构化报告生成失败：{str(e)}")

    def _bert_embed(self, text):
        """
        私有方法：使用BERT生成文本语义嵌入
        :param text: 输入文本
        :return: 语义嵌入向量（numpy数组）
        """
        if len(text.strip()) == 0:
            return torch.zeros(1, self.bert_model.config.hidden_size).numpy()

        # 文本编码
        inputs = self.bert_tokenizer(
            text,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=512
        ).to(self.device)

        # 生成语义嵌入
        with torch.no_grad():  # 关闭梯度计算，提升速度并节省显存
            outputs = self.bert_model(**inputs)
            # 取最后一层隐藏状态的均值作为句子嵌入
            embed = outputs.last_hidden_state.mean(dim=1).cpu().numpy()

        return embed

    def verify_source(self, structured_text, aligned_df):
        """
        来源校验：过滤LLM编造内容，保留语义匹配的有效内容
        :param structured_text: LLM生成的结构化报告
        :param aligned_df: 对齐结果DataFrame（原始数据）
        :return: 校验后的有效结构化报告
        """
        if len(structured_text.strip()) == 0 or aligned_df.empty:
            return structured_text

        try:
            # 1. 提取结构化报告中的来源编号
            source_pattern = r'\[(\d+)\]'
            source_nums = re.findall(source_pattern, structured_text)
            if not source_nums:
                return f"警告：该报告未包含有效来源编号，无法进行来源校验。\n\n{structured_text}"

            # 2. 分段校验（按来源编号拆分内容）
            valid_segments = []
            for src_num in source_nums:
                src_idx = int(src_num) - 1
                if src_idx < 0 or src_idx >= len(aligned_df):
                    continue  # 跳过无效来源编号

                # 提取原始文本与结构化报告中对应片段
                original_text = aligned_df.iloc[src_idx]["text"]
                # 匹配该来源编号对应的结构化内容
                segment_pattern = rf'([^[]+)\[{src_num}\]'
                segments = re.findall(segment_pattern, structured_text)
                if not segments:
                    continue

                for segment in segments:
                    segment = segment.strip()
                    if len(segment) == 0:
                        continue

                    # 3. 计算语义相似度
                    original_embed = self._bert_embed(original_text)
                    segment_embed = self._bert_embed(segment)
                    similarity = cosine_similarity(original_embed, segment_embed)[0][0]

                    # 4. 保留相似度高于阈值的内容
                    if similarity >= SEMANTIC_SIMILARITY_THRESHOLD:
                        valid_segments.append(f"{segment}[{src_num}]")

            # 5. 重组有效内容（保留原始报告结构）
            if valid_segments:
                valid_text = "\n".join(valid_segments)
                return f"✅ 来源校验通过，以下为有效结构化报告（相似度阈值：{SEMANTIC_SIMILARITY_THRESHOLD}）：\n\n{valid_text}"
            else:
                return "❌ 来源校验失败：未找到与原始数据语义匹配的有效内容。"

        except Exception as e:
            raise Exception(f"来源校验失败：{str(e)}")