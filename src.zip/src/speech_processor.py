# src/speech_processor.py
import whisper
import pandas as pd
from pyannote.audio import Pipeline
from config import WHISPER_MODEL, PYANNOTE_MODEL

class SpeechProcessor:
    def __init__(self, pyannote_token):
        """
        初始化语音处理模块
        :param pyannote_token: Hugging Face授权Token
        """
        try:
            # 1. 加载Whisper模型（自动下载缓存，首次运行较慢）
            print(f"正在加载Whisper模型：{WHISPER_MODEL}...")
            self.whisper_model = whisper.load_model(WHISPER_MODEL)
            print("Whisper模型加载完成")

            # 2. 加载Pyannote说话人分离管线
            print(f"正在加载Pyannote模型：{PYANNOTE_MODEL}...")
            self.speaker_pipeline = Pipeline.from_pretrained(
                PYANNOTE_MODEL,
                use_auth_token=pyannote_token
            )
            print("Pyannote模型加载完成")

        except Exception as e:
            raise Exception(f"模型加载失败：{str(e)}")

    def transcribe_audio(self, audio_path):
        """
        语音转写：生成带时间戳的转写结果
        :param audio_path: 处理后音频路径
        :return: 转写结果DataFrame（start, end, text）
        """
        try:
            # Whisper转写（word_timestamps=True：开启单词级时间戳，提升后续对齐精度）
            result = self.whisper_model.transcribe(
                audio_path,
                word_timestamps=True,
                verbose=False  # 关闭详细日志
            )

            # 提取片段级结果
            segments = []
            for seg in result.get("segments", []):
                segments.append({
                    "start": seg["start"],
                    "end": seg["end"],
                    "text": seg["text"].strip()
                })

            return pd.DataFrame(segments)

        except Exception as e:
            raise Exception(f"语音转写失败：{str(e)}")

    def separate_speakers(self, audio_path):
        """
        说话人分离：生成带时间戳的说话人标签
        :param audio_path: 处理后音频路径
        :return: 说话人分离结果DataFrame（start, end, speaker）
        """
        try:
            # 运行说话人分离管线
            diarization = self.speaker_pipeline(audio_path)

            # 提取说话人片段
            speakers = []
            for segment, _, speaker in diarization.itertracks(yield_label=True):
                speakers.append({
                    "start": segment.start,
                    "end": segment.end,
                    "speaker": speaker
                })

            return pd.DataFrame(speakers)

        except Exception as e:
            raise Exception(f"说话人分离失败：{str(e)}")

    def align_speech_text(self, transcribe_df, speaker_df):
        """
        对齐转写文本与说话人：基于时间戳重叠度匹配
        :param transcribe_df: 转写结果DataFrame
        :param speaker_df: 说话人分离结果DataFrame
        :return: 对齐结果DataFrame（start, end, speaker, text）
        """
        if transcribe_df.empty or speaker_df.empty:
            return pd.DataFrame(columns=["start", "end", "speaker", "text"])

        try:
            aligned_data = []
            for _, trans_row in transcribe_df.iterrows():
                trans_start = trans_row["start"]
                trans_end = trans_row["end"]
                trans_text = trans_row["text"]

                # 计算当前转写片段与所有说话人片段的重叠时长
                speaker_df["overlap"] = speaker_df.apply(
                    lambda x: max(0, min(trans_end, x["end"]) - max(trans_start, x["start"])),
                    axis=1
                )

                # 匹配重叠时长最大的说话人
                max_overlap_idx = speaker_df["overlap"].idxmax()
                max_overlap = speaker_df.loc[max_overlap_idx, "overlap"]

                if max_overlap > 0:  # 仅保留有有效重叠的结果
                    aligned_data.append({
                        "start": trans_start,
                        "end": trans_end,
                        "speaker": speaker_df.loc[max_overlap_idx, "speaker"],
                        "text": trans_text
                    })

            return pd.DataFrame(aligned_data)

        except Exception as e:
            raise Exception(f"文本与说话人对齐失败：{str(e)}")