# src/conflict_detector.py
import torch
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import cosine_similarity
from transformers import BertTokenizer, BertForSequenceClassification
from config import BERT_MODEL, CONFLICT_THRESHOLD, CLUSTER_NUM

class ConflictDetector:
    def __init__(self):
        """初始化冲突检测模块"""
        try:
            # 1. 冲突关键词库（可根据行业/场景扩展）
            self.conflict_keywords = {
                "支持", "反对", "同意", "拒绝", "认可", "质疑",
                "需要", "不需要", "必须", "禁止", "应该", "不应该",
                "可行", "不可行", "合理", "不合理", "成本", "预算",
                "优先", "延后", "采纳", "废弃"
            }

            # 2. 初始化TF-IDF向量器（基于冲突关键词）
            self.tfidf = TfidfVectorizer(vocabulary=self.conflict_keywords)

            # 3. 加载BERT分类模型（用于冲突深度判定）
            print(f"正在加载BERT冲突分类模型：{BERT_MODEL}...")
            self.bert_tokenizer = BertTokenizer.from_pretrained(BERT_MODEL)
            self.bert_classifier = BertForSequenceClassification.from_pretrained(
                "bert-base-uncased-finetuned-sst-2-english"  # 预训练情感分类模型，可微调为冲突分类
            )
            # 设备配置
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
            self.bert_classifier.to(self.device)
            self.bert_classifier.eval()  # 评估模式
            print(f"BERT冲突分类模型加载完成，使用设备：{self.device}")

        except Exception as e:
            raise Exception(f"冲突检测模块初始化失败：{str(e)}")

    def keyword_filter(self, text_list):
        """
        关键词预过滤：筛选包含冲突关键词的潜在冲突句
        :param text_list: 原始文本列表
        :return: 潜在冲突句列表（包含索引和文本）
        """
        if not text_list or len(text_list) == 0:
            return []

        try:
            # 过滤空文本
            valid_texts = [(idx, text) for idx, text in enumerate(text_list) if len(text.strip()) > 0]
            if not valid_texts:
                return []

            idx_list, content_list = zip(*valid_texts)

            # 生成TF-IDF矩阵
            tfidf_matrix = self.tfidf.fit_transform(content_list)

            # 筛选包含至少一个冲突关键词的文本
            conflict_candidates = []
            for idx, (orig_idx, text) in enumerate(valid_texts):
                tfidf_sum = tfidf_matrix[idx].sum()
                if tfidf_sum > 0:
                    conflict_candidates.append((orig_idx, text))

            return conflict_candidates

        except Exception as e:
            raise Exception(f"关键词预过滤失败：{str(e)}")

    def semantic_clustering(self, candidate_texts):
        """
        语义聚类：减少冗余，提取核心候选句
        :param candidate_texts: 潜在冲突句列表
        :return: 聚类后的核心句列表
        """
        if len(candidate_texts) <= 1:
            return candidate_texts

        try:
            # 1. 生成候选文本的BERT语义嵌入
            embeddings = []
            for text in candidate_texts:
                inputs = self.bert_tokenizer(
                    text,
                    return_tensors="pt",
                    padding=True,
                    truncation=True,
                    max_length=512
                ).to(self.device)

                with torch.no_grad():
                    outputs = self.bert_classifier.bert(**inputs)
                    embed = outputs.last_hidden_state.mean(dim=1).cpu().numpy()
                embeddings.append(embed[0])

            # 2. K-Means聚类（簇数可配置，最少为2）
            n_clusters = min(CLUSTER_NUM, len(candidate_texts))
            kmeans = KMeans(n_clusters=n_clusters, random_state=42)
            clusters = kmeans.fit_predict(embeddings)
            cluster_centers = kmeans.cluster_centers_

            # 3. 提取每个簇的核心句（最接近簇中心的文本）
            cluster_sentences = []
            for cluster_id in range(n_clusters):
                cluster_indices = [i for i, c in enumerate(clusters) if c == cluster_id]
                if not cluster_indices:
                    continue

                # 计算该簇内所有文本与簇中心的相似度
                cluster_embeds = [embeddings[i] for i in cluster_indices]
                similarities = [
                    cosine_similarity([embed], [cluster_centers[cluster_id]])[0][0]
                    for embed in cluster_embeds
                ]

                # 选择相似度最高的文本作为簇核心
                max_sim_idx = cluster_indices[similarities.index(max(similarities))]
                cluster_sentences.append(candidate_texts[max_sim_idx])

            return cluster_sentences

        except Exception as e:
            raise Exception(f"语义聚类失败：{str(e)}")

    def detect_conflict(self, text1, text2):
        """
        深度冲突检测：判定两个句子是否存在冲突
        :param text1: 句子1
        :param text2: 句子2
        :return: （是否冲突，冲突概率）
        """
        if len(text1.strip()) == 0 or len(text2.strip()) == 0:
            return False, 0.0

        try:
            # 1. 构造句对输入（使用[SEP]分隔两个句子）
            input_text = f"{text1} [SEP] {text2}"
            inputs = self.bert_tokenizer(
                input_text,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=512
            ).to(self.device)

            # 2. 模型推理
            with torch.no_grad():
                outputs = self.bert_classifier(**inputs)
                logits = outputs.logits
                # 计算概率（此处用情感分类模型近似，0=负面/冲突，1=正面/一致）
                prob = torch.softmax(logits, dim=1)[0][0].item()

            # 3. 判定是否冲突（概率高于阈值则认为是冲突）
            is_conflict = prob >= CONFLICT_THRESHOLD
            return is_conflict, prob

        except Exception as e:
            raise Exception(f"深度冲突检测失败：{str(e)}")