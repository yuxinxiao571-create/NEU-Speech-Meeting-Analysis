# src/data_preprocessor.py
import librosa
import soundfile as sf
import re
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords

# 自动下载NLTK所需资源
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')

class DataPreprocessor:
    def __init__(self):
        self.sample_rate = 16000  # 标准化采样率（Pyannote/Whisper推荐）
        self.stop_words = set(stopwords.words('english'))  # 英文停用词，如需中文可替换为jieba+中文停用词表

    def process_audio(self, audio_path, output_path):
        """
        音频预处理：读取、转单声道、静音去除、简单降噪、保存
        :param audio_path: 原始音频路径
        :param output_path: 处理后音频保存路径
        :return: 处理后音频路径
        """
        try:
            # 1. 读取音频（强制转单声道、指定采样率）
            y, sr = librosa.load(audio_path, sr=self.sample_rate, mono=True)
            if len(y) == 0:
                raise ValueError("读取到的音频数据为空，请检查输入音频文件是否有效")

            # 2. 静音检测与去除（top_db=20：静音阈值，可微调）
            intervals = librosa.effects.split(y, top_db=20)
            y_processed = []
            for start, end in intervals:
                y_processed.extend(y[start:end])
            if len(y_processed) == 0:
                raise ValueError("去除静音后音频数据为空，请降低top_db阈值或检查音频文件")
            y_processed = librosa.util.normalize(y_processed)  # 音频归一化

            # 3. 简单谱减法降噪（使用音频开头1秒作为噪声样本）
            noise_sample = y_processed[:min(1000, len(y_processed))]  # 避免音频过短报错
            y_denoised = librosa.effects.reduce_noise(y=y_processed, y_noise=noise_sample)

            # 4. 保存处理后音频
            sf.write(output_path, y_denoised, self.sample_rate)
            return output_path

        except Exception as e:
            raise Exception(f"音频预处理失败：{str(e)}")

    def process_text(self, text):
        """
        文本预处理：去除特殊字符、标准化空格、分词、去除停用词
        :param text: 原始文本
        :return: 处理后的纯净文本
        """
        if not isinstance(text, str) or len(text.strip()) == 0:
            return ""

        # 1. 过滤特殊字符（保留中英文、数字、空格）
        text = re.sub(r'[^\w\s\u4e00-\u9fa5]', '', text)
        # 2. 标准化空格（多个空格转为单个，去除首尾空格）
        text = re.sub(r'\s+', ' ', text).strip()
        # 3. 分词并去除停用词（仅英文，中文需替换为jieba分词）
        tokens = word_tokenize(text.lower())
        tokens = [token for token in tokens if token not in self.stop_words]
        return ' '.join(tokens)